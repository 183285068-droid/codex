from pathlib import Path
import itertools,json,hashlib,zipfile
import numpy as np,pandas as pd
from scipy.stats import false_discovery_control
R=Path(__file__).resolve().parent;d=pd.read_csv(R/'slice_metrics_by_threshold.csv');t=pd.read_csv(R/'slice_response_tests.csv');assert len(d)==28 and len(t)==12
for row in t.itertuples():
 dd=d[d['quantile']==row.quantile];v=dd[row.metric].to_numpy();h=dd.response.eq('responder').to_numpy();delta=v[h].mean()-v[~h].mean();null=[]
 for c in itertools.combinations(range(7),4):
  mask=np.zeros(7,bool);mask[list(c)]=True;null.append(v[mask].mean()-v[~mask].mean())
 assert np.isclose((np.abs(null)>=abs(delta)-1e-12).mean(),row.p_exact) and np.isclose(delta,row.difference)
assert np.allclose(false_discovery_control(t.p_exact.to_numpy()),t.BH_q_12_tests)
lines=['| 切片 | Q25源点 | Q50源点 | Q60源点 | Q75源点 | PGAM5检出巨噬源点 |','|---|---:|---:|---:|---:|---:|']
for sample,dd in d.groupby('sample',sort=False):
 n=dd.set_index('quantile');lines.append(f'| {sample} | {int(n.loc[.25,"n_high"])} | {int(n.loc[.5,"n_high"])} | {int(n.loc[.6,"n_high"])} | {int(n.loc[.75,"n_high"])} | {int(dd.n_detected.iloc[0])} |')
(R/'README.md').write_text('''# GSE238264：降低PGAM5阈值后的切片邻域敏感性分析

按用户要求，将PGAM5检出巨噬RNA源中的相对较高表达阈值按用户指定采用Q25，并保留Q50、Q60、Q75，并放宽每切片至少3个源点的汇总规则为至少1个。原始QC、巨噬门控、PGAM5零计数、CP10k及真实空间邻接保持不变。7张切片各来自1位患者，仍为4应答、3未应答独立单位；不能把源点数当成病例数。

这是看到低支持结果后按用户要求追加的探索性阈值敏感性分析，不替换先前预设主分析。Q25作为本轮采用的宽门控，涵盖检出源的约75%；Q50涵盖约一半，Q60涵盖约40%；不是绝对生物学高表达标准，边界并列值可能使比例偏离理论值。四个阈值共同报告，不按治疗标签或p值选择阈值。

'''+ '\n'.join(lines)+'''

HCC2R总共只有3个PGAM5检出巨噬RNA源，Q50仍只有2个较高表达源；不能靠调整分位阈值消除这种原始稀疏性。若纳入全部3个，则应称PGAM5检出/阳性源，不能继续称高表达。所有图标出每切片源点n，n<3的估计保留但稳定性有限。

比较三个固定邻域指标（巨噬RNA邻居比例、T-RNA邻居比例、邻居成纤维RNA平均程序），每源先汇总再每切片等权平均。无T邻居的T覆盖为0；本轮没有将缺少T目标的连续T状态程序填0。每个比较枚举全部35种4/3标签分配，以绝对均值差作双侧统计；4阈值×3指标共12项统一BH校正。只放宽汇总门槛不增加独立样本数，不改变治疗后关联的解释边界。

完整结果见slice_response_tests.csv。各阈值结论必须结合全部12项校正结果，不依据未校正p或单张HE图宣称PGAM5调控疗效。血样/临床特征与测序质量混杂仍未消除。

提供7组阈值HE融合图（Q25/Q50/Q60/Q75）及一组切片比较图，均有PNG/PDF；HE使用各切片官方缩放，橙色圈为对应阈值源点。全部28个源分组检查、35配置p及共同BH复算通过；基线完整输入/QC/空间指标核验见相邻原分析目录。本轮结果包不重复打包原始图像和计数矩阵。

复现需完整仓库的相邻GSE238264_PGAM5_spatial_response目录以及7个已解压原包：设置GSE238264_INPUT为包含HCC1R至HCC7NR的目录，使用基线requirements.txt环境，运行python analyze.py、python plot_comparisons.py、python plot_q25.py，最后运行python package_results.py。输入基线注释SHA256记录在input_manifest.json。

原分析：[GSE238264_PGAM5_spatial_response](../GSE238264_PGAM5_spatial_response/README.md)。
''')
with (R/'README.md').open('a') as f:
 row=t[(t['quantile']==.25)&(t.metric=='T_fraction')].iloc[0]
 f.write(f'\n## Q25结果\n\nQ25采用阈值为每切片PGAM5检出巨噬RNA源的归一化表达第25百分位。应答组邻近T-RNA覆盖均值{100*row.mean_responder:.2f}%，未应答{100*row.mean_nonresponder:.2f}%；精确p={row.p_exact:.5f}，12项统一BH q={row.BH_q_12_tests:.5f}。逐项结果见slice_response_tests.csv。[Q25切片对比图](figures/Q25_response_comparisons.png)。本轮为用户指定阈值后的探索性补充，不覆盖原预设主分析；放宽每切片至少3源点为至少1源点后，所有7切片均参与比较，低支持病例不构成稳定机制证据。\n')
(R/'.gitignore').write_text('__pycache__/\n');z=R/'GSE238264_PGAM5_threshold_sensitivity_all_results.zip';files=[p for p in sorted(R.rglob('*')) if p.is_file() and p!=z and p.name!='package_manifest.json' and '__pycache__' not in p.parts];records=[dict(path=str(p.relative_to(R)),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size) for p in files];(R/'package_manifest.json').write_text(json.dumps(records,indent=2))
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as f:
 for p in files+[R/'package_manifest.json']:f.write(p,p.relative_to(R))
with zipfile.ZipFile(z) as f:
 assert f.testzip() is None
 for rec in records:assert hashlib.sha256(f.read(rec['path'])).hexdigest()==rec['sha256']
print('Independent permutation/BH checks and ZIP verified:',z.stat().st_size,'bytes')
